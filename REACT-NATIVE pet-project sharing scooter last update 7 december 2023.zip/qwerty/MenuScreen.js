import React from 'react';
import { View, StyleSheet, TouchableOpacity, Text } from 'react-native';
import { useNavigation } from '@react-navigation/native';

const MenuScreen = () => {
  const navigation = useNavigation();

  const handleMenuItemPress = (item) => {
    if (item === "Профиль") {
      navigation.navigate("Profile");
    }
  };

  return (
    <View style={styles.container}>
      {/* Теперь кнопки рендерятся непосредственно в MenuScreen */}
      <TouchableOpacity style={styles.itemContainer} onPress={() => handleMenuItemPress("Профиль")}>
        <Text style={styles.itemText}>Профиль</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.itemContainer} onPress={() => handleMenuItemPress("Оплата")}>
        <Text style={styles.itemText}>Оплата</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.itemContainer} onPress={() => handleMenuItemPress("История поездок")}>
        <Text style={styles.itemText}>История поездок</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.itemContainer} onPress={() => handleMenuItemPress("О приложении")}>
        <Text style={styles.itemText}>О приложении</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.itemContainer} onPress={() => handleMenuItemPress("Поддержка")}>
        <Text style={styles.itemText}>Поддержка</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'stretch',
    padding: 20,
  },
  itemContainer: {
    padding: 15,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: 'lightgray',
    borderRadius: 10,
  },
  itemText: {
    fontSize: 18,
    textAlign: 'center',
  },
});


export default MenuScreen;
