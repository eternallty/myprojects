import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage'; // импорт AsyncStorage

export default function RegistrationScreen() {
  const navigation = useNavigation();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');

  const handleRegistration = async () => { // Объявляем функцию как асинхронную
    if (name === '' || email === '' || phone === '' || password === '') { // Исправляем логические операторы на ||
      alert('Пожалуйста, заполните все поля перед регистрацией.');
      return; // Прерываем выполнение функции, если какое-то поле не заполнено
    }
    if (name.length < 5 || name.length > 50) { // Исправляем логический оператор на ||
      alert('Имя должно содержать от 5 до 50 символов.');
      return;
    }
    if (!email.includes('@') || email.length < 8) { // Исправляем логический оператор на ||
      alert('Пожалуйста, введите действительный адрес электронной почты.');
      return;
    }
    if (phone.length < 5 || phone.length > 50) {
      alert('Пожалуйста, введите действительный номер телефона (11 цифр).');
      return;
    }
    if (password.length < 8 || password.length > 50) { // Исправляем логический оператор на ||
      alert('Пароль должен содержать от 8 до 50 символов.');
      return;
    }
    try {
      // Сохраняем данные в AsyncStorage
      await AsyncStorage.setItem('userData', JSON.stringify({ name, email, phone, password }));
      alert('Успешная регистрация!');
      navigation.navigate('Main', { screen: 'Menu' });
    } catch (error) {
      console.error('Ошибка сохранения данных:', error);
    }
  };
  const handleLogin = () => {
  navigation.navigate('Login'); // Замените 'Login' на имя вашего экрана входа
};


  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Name"
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Email"
        onChangeText={setEmail}
      />
      <TextInput
        style={styles.input}
        placeholder="Phone Number"
        onChangeText={setPhone}
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry={true}
        onChangeText={setPassword}
      />
      <TouchableOpacity
        style={styles.registerButton}
        onPress={handleRegistration}
      >
        <Text style={styles.buttonText}>Register</Text>
      </TouchableOpacity>
    <TouchableOpacity
        style={styles.loginButton}
        onPress={handleLogin}
      >
        <Text style={styles.buttonText}>Login</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 8,
    margin: 10,
    padding: 10,
    width: 300,
  },
  registerButton: {
    backgroundColor: 'blue',
    padding: 15,
    borderRadius: 8,
    marginTop: 20,
  },
  loginButton: {
    backgroundColor: 'blue',
    padding: 15,
    borderRadius: 8,
    marginTop: 20,
  },
  buttonText: {
    color: 'white',
    textAlign: 'center',
    fontSize: 18,
  },
});
