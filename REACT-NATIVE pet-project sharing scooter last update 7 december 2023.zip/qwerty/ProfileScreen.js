import React, { useState } from 'react';
import { View, StyleSheet, Text, TextInput, CheckBox } from 'react-native';

const ProfileScreen = ({ user }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState(user.password); 

  const handlePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  return (
    <View style={styles.container}>
      <View style={styles.fieldContainer}>
        <Text style={styles.fieldLabel}>Имя</Text>
        <TextInput style={styles.input} value={user.name} readOnly />
      </View>
      <View style={styles.fieldContainer}>
        <Text style={styles.fieldLabel}>Email</Text>
        <TextInput style={styles.input} value={user.email} readOnly />
      </View>
      <View style={styles.fieldContainer}>
        <Text style={styles.fieldLabel}>Номер телефона</Text>
        <TextInput style={styles.input} value={user.phoneNumber.toString()} readOnly />
      </View>
      <View style={styles.fieldContainer}>
        <Text style={styles.fieldLabel}>Пароль</Text>
        <View style={styles.passwordContainer}>
          <TextInput
            style={[styles.input, styles.passwordInput]}
            value={showPassword ? password : '**********'}
            secureTextEntry={!showPassword}
            readOnly
          />
          <CheckBox value={showPassword} onValueChange={handlePasswordVisibility} />
          <Text style={styles.showPasswordLabel}>Показать пароль</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f7f7f7',
  },
  fieldContainer: {
    marginBottom: 15,
  },
  fieldLabel: {
    marginBottom: 5,
    fontSize: 16,
    fontWeight: 'bold',
  },
  input: {
    borderWidth: 1,
    borderColor: 'lightgray',
    borderRadius: 5,
    padding: 10,
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  passwordInput: {
    flex: 1,
  },
  showPasswordLabel: {
    marginLeft: 10,
  },
});

export default ProfileScreen;
