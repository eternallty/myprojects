import {StyleSheet} from 'react-native';
import { vw, vh } from 'react-native-expo-viewport-units';

export default MapStyles = StyleSheet.create({

    map: {

        width: vw(100),
        height: vh(100),

    },

})