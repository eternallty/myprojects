// MenuScreen.js

import React, { useState } from 'react';
import { View, Text, StyleSheet, Button, TouchableOpacity } from 'react-native';

const MenuScreen = ({ navigation }) => {
  const user = {
    name: 'Иван',
    email: 'ivan@example.com',
    phone: '1234567890',
    // Добавьте другие данные пользователя, если необходимо
  };

  const handleLogout = () => {
    // Логика для выхода из профиля, например, сброс состояния пользователя и навигации на экран регистрации
    navigation.navigate('Registration');
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.profileButton}
        onPress={() => navigation.navigate('Profile', { user: user, onLogout: handleLogout })}
      >
        <Text style={styles.profileButtonText}>Профиль</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  profileButton: {
    backgroundColor: 'lightblue',
    padding: 10,
    borderRadius: 5,
  },
  profileButtonText: {
    fontWeight: 'bold',
    color: 'white',
  },
});

export default MenuScreen;
